# automatons-in-python
Small set of exercises/projects for the subject "Autómatas y Lenguajes Formales" (Automatons and formal languages).
